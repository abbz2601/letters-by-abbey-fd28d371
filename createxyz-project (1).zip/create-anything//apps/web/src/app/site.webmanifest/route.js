export async function GET() {
  const manifest = {
    "name": "Letters by Abbey",
    "short_name": "LettersByAbbey", 
    "icons": [
      {
        "src": "favicon-16x16.png",
        "sizes": "16x16",
        "type": "image/png"
      },
      {
        "src": "favicon-32x32.png", 
        "sizes": "32x32",
        "type": "image/png"
      },
      {
        "src": "apple-touch-icon.png",
        "sizes": "180x180", 
        "type": "image/png"
      }
    ],
    "start_url": "/",
    "display": "standalone",
    "theme_color": "#ffffff",
    "background_color": "#ffffff"
  };

  return new Response(JSON.stringify(manifest), {
    headers: {
      'Content-Type': 'application/manifest+json',
    },
  });
}