export async function GET() {
  // Redirect to the apple touch icon on CDN
  return Response.redirect('https://ucarecdn.com/29b9da9c-e91a-40a0-bfbb-7c0db2955ca0/-/format/auto/', 301);
}